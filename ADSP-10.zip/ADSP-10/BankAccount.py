class InsufficientAmountError(Exception):
    def __init__(self,message="Insufficient Amoount for the transaction"):
        self.message=message
        super().__init__(self.message)
class Bank:
    def __init__(self,account_holder,account_number,balance=0):
        self.account_holder=account_holder
        self.account_number=account_number
        self.balance=balance
    def deposit(self,amount):
        if amount>0:
           self.balance+=amount
           print(f"Deposited {amount}.new balance {self.balance}")
        else:
            print("for deposit amount should be greater than 0")
    def withdraw(self,amount):
        if amount<=0:
            print("the amount should be greater than 0")
            return
        if amount > self.balance:
            raise InsufficientAmountError(f" unable to withdraw {amount}.Insuuficient amount")
        else:
            self.balance -=amount
            print(f" withdaw {amount}.new balance {self.balance}")
    def get_balance(self):
        return self.balance
    def set_balnce(self, amount):
        self.balance=amount
        print(f"balance {self.balance}")
def handle_account_operations():
    account_holder = input("enter account holder name:")
    account_number = input("enter account number:")
    initial_balance = float(input("Enter starting balance: "))
    account = Bank(account_holder, account_number, initial_balance)
    while True:
        print("\n Options:")
        print("1. deposit the money")
        print("2. withdraw money")
        print("3.check balance")
        print("4.exist")
        choice=input("enter your choice (1/2/3/4):")
        if choice == '1':
            try:
                deposit_amount = float(input("enter the amount to deposit:"))
                account.deposit(deposit_amount)
            except ValueError:
                print("Invalid Number!please enter a number:") 
        elif choice == '2':
            try:
                withdraw_amount = float(input("Enter amount to withdraw: "))
                account.withdraw(withdraw_amount)
            except ValueError:
                print("Invalid amount! Please enter a number.")
            except InsufficientAmountError as e:
                print(f"Error: {e}")
        elif choice == '3':
            print(f"current balance:{account.get_balance()}")    
        elif choice == '4':
            print("existing the program:")
            break  
        else:
            print("you entered wrong option:")
if __name__ == "__main__":
    handle_account_operations()              

                                
                             