class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
class Queue:
    def __init__(self):
        self.front=None
        self.rear=None
        self.size=0
    def enqueue(self,data):
        new_node=Node(data)
        if self.rear is None:
            self.front=self.rear=new_node
        else:
            self.rear.next=new_node
            self.rear= new_node

        self.size+=1
        print(f"Enqueued:{data}")
    def dequeue(self):
        if self.is_empty():
            print("queue is empty can't dequeue")
            return None
        dequeue_data=self.front.data
        self.front=self.front.next
        if self.front is None:
            self.rear = None
        self.size-=1
        print(f"dequeued element:{dequeue_data}")
        return dequeue_data
    def is_empty(self):
        return self.front is None
    def get_size(self):
        return self.size
    def peek(self):
        if self.is_empty():
            print("queue is empty no front element")
            return None
        return self.front.data
    def display(self):
        if self.is_empty():
            print("queue is empty")
        else:
            current=self.front
            while current:
                print(current.data ,end="->")
                current=current.next
            print("None")
if __name__ == "__main__":
    q = Queue()
    
    while True:
        print("\nQueue Operations:")
        print("1. Enqueue")
        print("2. Dequeue")
        print("3. Display Queue")
        print("4. Check if Queue is Empty")
        print("5. Get Queue Size")
        print("6.peek")
        print("7. Exit")
        
        choice = int(input("Enter choice (1-7): "))
        
        if choice == 1:
            item = int(input("Enter a number to enqueue: "))
            q.enqueue(item)
        elif choice == 2:
             q.dequeue()
            
        elif choice == 3:
            q.display()
        elif choice == 4:
            if q.is_empty():
                print("Queue is empty.")
            else:
                print("Queue is not empty.")
        elif choice == 5:
            print("Queue size:", q.get_size())
        elif choice == 6:
            print("Peek element:",q.peek())
        elif choice == 7:
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Please try again.")



