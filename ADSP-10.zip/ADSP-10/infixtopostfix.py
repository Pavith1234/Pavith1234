def precedence (operator):
    if operator == '^':
        return 3
    elif operator == '*' or operator =='/':
        return 2
    elif operator == '-' or operator == '+':
        return 1
    else:
        return 0
def infix_to_postfix(expression):
    stack=[]
    output=[]
    for char in expression:
        if char.isalnum():
            output.append(char)
        elif char =='(':
            stack.append(char)
        elif char == ')':
            while stack and stack[-1]!='(':
                output.append(stack.pop())
            stack.pop()
        else:
            while (stack and precedence(stack[-1]) >= precedence(char)):
                output.append(stack.pop())
            stack.append(char)
    while stack:
        output.append(stack.pop())
    return ''.join(output)
infix_Expression= input("Enter the Expression")
postfix_expression = infix_to_postfix(infix_Expression)
print ("postfix Expression",postfix_expression)

       
