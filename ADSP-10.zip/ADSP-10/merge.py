def MERE(left,right):
    i=0
    m=len(left)
    j=0
    l=len(right)
    b=[]
    while i<m and j<l:
        if(left[i]<right[j]):
            b.append(left[i])
            i=i+1
        else:
            b.append(right[j])
            j=j+1
    while(i<m):
        b.append(left[i])
        i=i+1
    while(j<l):
       b.append(right[j])
       j=j+1
    return b

def RMSORT(a):
    if len(a)<=1:
        return a
    else:
        mid=len(a) //2
        left=a[:mid]
        right=a[mid:]
        left=RMSORT(left)
        right=RMSORT(right)
    return MERE(left,right)
n=int(input("enter the value:"))
a=[]
for i in range(n):
    e=int(input("element is:"))
    a.append(e)
sorted= RMSORT(a)
print("sorted elements:",sorted)
    
    
