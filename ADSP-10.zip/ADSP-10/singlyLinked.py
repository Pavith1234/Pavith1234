class Node:
    def __init__(self, value):
        self.value = value  # The value of the node
        self.next = None    # Pointer to the next node (default is None)

class LinkedList:
    def __init__(self):
        self.head = None  # Initially, the list is empty, so head is None

    # Method to insert a node at the beginning (prepend)
    def prepend(self, value):
        new_node = Node(value)   # Create a new node
        new_node.next = self.head  # Point the new node's next to the current head
        self.head = new_node      # Update the head to the new node

    # Method to display the linked list
    def display(self):
        current = self.head
        if not current:
            print("The list is empty.")
            return
        while current:
            print(current.value, end=" -> " if current.next else "")
            current = current.next
        print()  # Print newline after displaying the list

# Helper function to get dynamic input from the user
def get_dynamic_input():
    user_input = input("Enter space-separated integers to insert at the beginning of the list: ")
    # Convert input to a list of integers
    return list(map(int, user_input.split()))

# Main program
def main():
    linked_list = LinkedList()
    
    # Get dynamic input from the user
    values = get_dynamic_input()

    # Prepend each value at the beginning of the linked list
    for value in values:
        linked_list.prepend(value)

    # Display the final linked list
    print("Linked List after insertion at the beginning:")
    linked_list.display()

if __name__ == "__main__":
    main()
