def precedence (operator):
    if operator == '^':
        return 3
    elif operator == '*' or operator =='/':
        return 2
    elif operator == '-' or operator == '+':
        return 1
    else:
        return 0
def infix_to_postfix(expression):
    stack=[]
    output=[]
    for char in expression:
        if char.isalnum():
            output.append(char)
        elif char =='(':
            stack.append(char)                                          
        elif char == ')':
            while stack and stack[-1]!='(':
                output.append(stack.pop())
            stack.pop()
        else:
            while (stack and precedence(stack[-1]) >= precedence(char)):
                output.append(stack.pop())
            stack.append(char)
    while stack:
        output.append(stack.pop())
    return ''.join(output)
def apply_operator(operand1, operand2, char):
        if char == '+':
            return operand1 + operand2
        elif char == '-':
            return operand1 - operand2
        elif char == '*':
            return operand1 * operand2
        elif char == '/':
            if operand2 == 0:
                raise ZeroDivisionError("Cannot divide by zero.")
            else:
                return operand1 / operand2
        elif char == '^':
            return operand1 ** operand2
        
        return 0
def eval_postfix(expression):
    stack=[]
    for char in expression:
        if char.isdigit():
            stack.append(int (char))
        else:
            operand2 = stack.pop()
            operand1= stack.pop()
            result = apply_operator(operand1, operand2, char)
            stack.append(result)
    return stack.pop()
    
infix_Expression= input("Enter the Expression")
postfix_expression = infix_to_postfix(infix_Expression)
print ("postfix Expression",postfix_expression)
postfix = eval_postfix(postfix_expression)
print("Postfix Evaluation", postfix)
       
