class Node:
    def __init__(self,data):
        self.data=data
        self.prev=None
        self.next=None
class doubleList:
    def __init__(self):
        self.head=None
    def insert(self,data):
        new_node=Node(data)
        if not self.head:
            self.head= new_node
            return
        last_node=self.head
        while last_node.next:
            last_node= last_node.next
        last_node.next= new_node
        new_node.prev= last_node
    def display(self):
        if  not self.head:
            print("the list is empty:")
            return
        current= self.head
        while current:
            print(current.data, end="<->"if current.next else"")
            current=current.next
        print()
    def delete(self,value):
        current = self.head
        while current:
            if current.data== value:
                if current.prev:
                    current.prev.next=current.next
                if current.next:
                    current.next.prev= current.prev
                if current== self.head:
                    self.head= current.next
                current= None
                print(f"deleted:{value}")
                return
            current= current.next
        print(f"the {value} is not found in the list")
    def dispaly(self):
        if self.head is None:
            print("the list is empty")
        current=self.head
        while current:
            print(current.data,end="<->" if current.next else "")
            current=current.next
        print()
if __name__ == "__main__" :
    dl= doubleList()
    while True:
        print("\n doubleList operations")
        print("1. insertion")
        print("2.deletion")
        print("3.display")
        print("4.exist")
        choice= int(input("enter the choice:"))
        if choice== 1:
            data= int(input("enter the element into the list"))
        
            dl.insert(data)
            print(f"Inserted{data}  the list")
        elif choice== 2:
            value= int(input("enter the value to be deleted "))
            dl.delete(value)
        elif choice== 3:
            print("current list",end="")
            dl.display()
        elif choice ==4:
            print("Existing the program ")
            break
        else:
            print("Invalid Input plaese try again")
