class Node:
    def __init__(self,value):
        self.data=value
        self.next=None
class LinkedList:
    def __init__(self):
        self.head=None
    def insFirst(self,value):
        newnode=Node(value)
        newnode.next=self.head
        self.head=newnode
    def display(self):
        temp=self.head
        if self.head==None:
            print("the list is empty")
        else:
            while(temp!=None):
                print(temp.value, end=" -> " if temp.next else "")
                temp=temp.next
            print()  
def get_input():
    n=input("enter data")
    return list(map(int, n.split()))
def main():
    while(1):
        print('1.insert beginning|n 2.display|n 3.exist')
        ch=print("enter your choice:")
        def switch_case(ch):
            if ch == 1:
                linked_list=LinkedList()
                values=get_input()
                break
           elif ch==2:
                input("enter the element into the list"))
                    linked_list.insFirst(value)
                    linked_list.display()
            break
            else:
                exit(0)
                default:print("you enteres wrong option")
if __name__ == "__main__":
    main()

