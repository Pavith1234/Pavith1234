# Custom exception class for insufficient funds
class InsufficientFundsError(Exception):
    def __init__(self, message="Insufficient funds for this transaction"):
        self.message = message
        super().__init__(self.message)

# BankAccount class
class BankAccount:
    def __init__(self, account_holder, account_number, balance=0):
        """Initialize the bank account with account holder, account number, and an optional starting balance."""
        self.account_holder = account_holder
        self.account_number = account_number
        self.balance = balance

    def deposit(self, amount):
        """Deposit money into the account."""
        if amount > 0:
            self.balance += amount
            print(f"Deposited {amount}. New balance: {self.balance}")
        else:
            print("Deposit amount must be greater than 0.")

    def withdraw(self, amount):
        """Withdraw money from the account. Raise InsufficientFundsError if funds are insufficient."""
        if amount <= 0:
            print("Withdrawal amount must be greater than 0.")
            return
        if amount > self.balance:
            # Raise a custom exception if there are insufficient funds
            raise InsufficientFundsError(f"Unable to withdraw {amount}. Insufficient funds!")
        else:
            self.balance -= amount
            print(f"Withdrew {amount}. New balance: {self.balance}")

    def get_balance(self):
        """Get the current balance of the account."""
        return self.balance

    def set_balance(self, amount):
        """Set an initial balance for the account."""
        self.balance = amount
        print(f"Balance has been set to {self.balance}")

# Function to handle dynamic inputs and perform operations
def handle_account_operations():
    # Collect dynamic inputs for account creation
    account_holder = input("Enter account holder name: ")
    account_number = input("Enter account number: ")
    initial_balance = float(input("Enter starting balance: "))

    # Create the bank account object
    account = BankAccount(account_holder, account_number, initial_balance)

    # Perform operations based on user input
    while True:
        print("\nOptions:")
        print("1. Deposit money")
        print("2. Withdraw money")
        print("3. Check balance")
        print("4. Exit")
        
        choice = input("Enter your choice (1/2/3/4): ")

        if choice == "1":
            try:
                deposit_amount = float(input("Enter amount to deposit: "))
                account.deposit(deposit_amount)
            except ValueError:
                print("Invalid amount! Please enter a number.")

        elif choice == "2":
            try:
                withdraw_amount = float(input("Enter amount to withdraw: "))
                account.withdraw(withdraw_amount)
            except ValueError:
                print("Invalid amount! Please enter a number.")
            except InsufficientFundsError as e:
                print(f"Error: {e}")

        elif choice == "3":
            print(f"Current balance: {account.get_balance()}")

        elif choice == "4":
            print("Exiting the program.")
            break

        else:
            print("Invalid choice! Please try again.")

# Example Usage
if __name__ == "__main__":
    handle_account_operations()
