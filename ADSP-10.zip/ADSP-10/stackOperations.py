class Stack:
    def __init__(self):
        self.stack=[]
    def push(self,item):
        self.stack.append(item)
    def pop(self):
        if not self.is_empty():
            return self.stack.pop()
        else:
            print("stack is empty")
    def is_empty(self):
        return len(self.stack)==0
    def size(self):
        return len(self.stack)
if __name__ == "__main__":
    stack=Stack()
    numbers=input("enter the numbers ").split()
    for num in numbers:
        stack.push(int(num))
    print("numbers in reverse order")
    while not stack.is_empty():
        print(stack.pop())

    