from abc import ABC, abstractmethod

# Abstract base class
class Polygon(ABC):
    @abstractmethod
    def get_details(self):
        pass

    @abstractmethod
    def calculate_area(self):
        pass

    @abstractmethod
    def calculate_perimeter(self):
        pass

# Rectangle class derived from Polygon
class Rectangle(Polygon):
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def get_details(self):
        print(f"Rectangle with length {self.length} and width {self.width}")

    def calculate_area(self):
        return self.length * self.width

    def calculate_perimeter(self):
        return 2 * (self.length + self.width)

# Square class derived from Polygon
class Square(Polygon):
    def __init__(self, side):
        self.side = side

    def get_details(self):
        print(f"Square with side length {self.side}")

    def calculate_area(self):
        return self.side ** 2

    def calculate_perimeter(self):
        return 4 * self.side

# Triangle class derived from Polygon
class Triangle(Polygon):
    def __init__(self, a, b, c, height):
        self.a = a
        self.b = b
        self.c = c
        self.height = height

    def get_details(self):
        print(f"Triangle with sides {self.a}, {self.b}, {self.c} and height {self.height}")

    def calculate_area(self):
        return 0.5 * self.b * self.height

    def calculate_perimeter(self):
        return self.a + self.b + self.c

# Function to demonstrate polymorphism using dynamic inputs
def polygon_operations():
    # Get dynamic input from the user to create polygons
    print("Choose the type of polygon to create:")
    print("1. Rectangle")
    print("2. Square")
    print("3. Triangle")
    
    choice = int(input("Enter your choice (1/2/3): "))
    
    if choice == 1:
        length = float(input("Enter the length of the rectangle: "))
        width = float(input("Enter the width of the rectangle: "))
        polygon = Rectangle(length, width)
        
    elif choice == 2:
        side = float(input("Enter the side length of the square: "))
        polygon = Square(side)
        
    elif choice == 3:
        a = float(input("Enter side a of the triangle: "))
        b = float(input("Enter side b of the triangle: "))
        c = float(input("Enter side c of the triangle: "))
        height = float(input("Enter the height of the triangle: "))
        polygon = Triangle(a, b, c, height)
        
    else:
        print("Invalid choice!")
        return

    # Demonstrating polymorphism by calling the same methods on the base class reference
    polygon.get_details()
    print(f"Area: {polygon.calculate_area()}")
    print(f"Perimeter: {polygon.calculate_perimeter()}")

# Example usage
if __name__ == "__main__":
    polygon_operations()
