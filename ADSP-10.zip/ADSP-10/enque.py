class Queue:
    def __init__(self):
        self.queue = []
    
    def enqueue(self, item):
        """Add an item to the queue."""
        self.queue.append(item)
    
    def dequeue(self):
        """Remove an item from the queue and return it."""
        if not self.is_empty():
            return self.queue.pop(0)
        else:
            print("Queue is empty, cannot dequeue.")
            return None
    
    def is_empty(self):
        """Check if the queue is empty."""
        return len(self.queue) == 0
    
    def size(self):
        """Return the size of the queue."""
        return len(self.queue)
    
    def display(self):
        """Display the elements of the queue in FIFO order."""
        if self.is_empty():
            print("Queue is empty.")
        else:
            print("Queue contents (FIFO order):", ' '.join(map(str, self.queue)))


# Driver Code to test the queue
if __name__ == "__main__":
    q = Queue()
    
    while True:
        print("\nQueue Operations:")
        print("1. Enqueue")
        print("2. Dequeue")
        print("3. Display Queue")
        print("4. Check if Queue is Empty")
        print("5. Get Queue Size")
        print("6. Exit")
        
        choice = int(input("Enter choice (1-6): "))
        
        if choice == 1:
            item = int(input("Enter a number to enqueue: "))
            q.enqueue(item)
        elif choice == 2:
            dequeued_item = q.dequeue()
            if dequeued_item is not None:
                print(f"Dequeued: {dequeued_item}")
        elif choice == 3:
            q.display()
        elif choice == 4:
            if q.is_empty():
                print("Queue is empty.")
            else:
                print("Queue is not empty.")
        elif choice == 5:
            print(f"Queue size: {q.size()}")
        elif choice == 6:
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Please try again.")
