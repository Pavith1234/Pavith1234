class Node:
    def __init__(self,data):
        self.data= data
        self.next=None
class Stack:
    def __init__(self):
        self.top=None
        self.count=0
    def push(self,item):
        new_node= Node(item)
        new_node.next= self.top
        self.top=new_node
        self.count+=1
    def pop(self):
        if not self.is_empty():
            popped_node= self.top
            self.top=self.top.next
            self.count-=1
            return popped_node.data
        else:
            print('stack is empty')
            return None
        
    def is_empty(self):
        return self.top is None
    def size(self):
        return self.count
if __name__ == "__main__":
    stack=Stack()
    numbers=input("enter the numbers ").split()
    for num in numbers:
        stack.push(int(num))
    print("numbers in reverse order")
    while not stack.is_empty():
        print(stack.pop())

    