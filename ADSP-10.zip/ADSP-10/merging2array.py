n=int(input("enter the value:"))
a=[]
for i in range(n):
    e=int(input("element is:"))
    a.append(e)
s=int(input("enter the size of S:"))
c=[]
for i in range(s):
    ele=int(input("element of s is:"))
    c.append(ele)
i=0
j=0
b=[]
while i<n and j<s:
      if(a[i]<c[j]):
         b.append(a[i])
         i=i+1
      else:
        b.append(c[j])
        j=j+1
while(i<n):
        b.append(a[i])
        i=i+1
while(j<s):
       b.append(a[j])
       j=j+1
print("sorted elements:",b)
    
    
